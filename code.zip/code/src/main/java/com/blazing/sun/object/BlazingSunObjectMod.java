package com.blazing.sun.object;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class BlazingSunObjectMod implements ModInitializer {
    public static final String MOD_ID = "blazing-sun-object";

    // ---------- 回血管理 ----------
    private static final Map<UUID, Integer> HEAL_REMAINING = new HashMap<>();
    private static final Map<UUID, Integer> HEAL_TICK_COUNTER = new HashMap<>();

    public static void startHealing(PlayerEntity player) {
        UUID uuid = player.getUuid();
        HEAL_REMAINING.put(uuid, 10);
        HEAL_TICK_COUNTER.put(uuid, 0);
    }

    // ---------- 防反随机数生成器 ----------
    private static final Random RANDOM = new Random();

    // ---------- 注册剑 ----------
    public static final Item BLAZING_SWORD = new BlazingSwordItem(
            ModToolMaterials.BLAZING_SWORD,
            0,
            -2.2F,
            new Item.Settings()
    );

    // ---------- 物品组 ----------
    public static final RegistryKey<ItemGroup> BLAZING_GROUP_KEY =
            RegistryKey.of(Registries.ITEM_GROUP.getKey(), new Identifier(MOD_ID, "general"));

    public static final ItemGroup BLAZING_GROUP = FabricItemGroup.builder()
            .displayName(Text.translatable("itemGroup.blazing-sun-object.general"))
            .icon(() -> new ItemStack(BLAZING_SWORD))
            .build();

    @Override
    public void onInitialize() {
        // 注册剑
        Registry.register(Registries.ITEM,
                new Identifier(MOD_ID, "blazing_sword"),
                BLAZING_SWORD
        );

        // 注册物品组
        Registry.register(Registries.ITEM_GROUP, BLAZING_GROUP_KEY, BLAZING_GROUP);
        ItemGroupEvents.modifyEntriesEvent(BLAZING_GROUP_KEY)
                .register(content -> content.add(BLAZING_SWORD));

        // 回血 tick 处理（已有）
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (UUID uuid : HEAL_REMAINING.keySet().toArray(new UUID[0])) {
                PlayerEntity player = server.getPlayerManager().getPlayer(uuid);
                if (player == null || player.isRemoved()) {
                    HEAL_REMAINING.remove(uuid);
                    HEAL_TICK_COUNTER.remove(uuid);
                    continue;
                }
                int remaining = HEAL_REMAINING.getOrDefault(uuid, 0);
                if (remaining <= 0) {
                    HEAL_REMAINING.remove(uuid);
                    HEAL_TICK_COUNTER.remove(uuid);
                    continue;
                }
                int counter = HEAL_TICK_COUNTER.getOrDefault(uuid, 0) + 1;
                if (counter >= 20) {
                    player.heal(4.0f);
                    remaining--;
                    HEAL_REMAINING.put(uuid, remaining);
                    HEAL_TICK_COUNTER.put(uuid, 0);
                } else {
                    HEAL_TICK_COUNTER.put(uuid, counter);
                }
            }
        });

        // ========== 新增：防反事件监听 ==========
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // 只处理玩家
            if (!(entity instanceof PlayerEntity player)) return true; // 允许伤害

            // 检查是否手持烈焰长剑（主手或副手）
            ItemStack mainHand = player.getMainHandStack();
            ItemStack offHand = player.getOffHandStack();
            boolean hasSword = mainHand.getItem() == BLAZING_SWORD || offHand.getItem() == BLAZING_SWORD;
            if (!hasSword) return true; // 没拿剑，正常受伤

            // 10% 概率触发防反
            if (RANDOM.nextFloat() < 0.1f) {
                // 免疫本次伤害
                // 对攻击者造成15点伤害（如果攻击者存在且是生物）
                if (source.getAttacker() instanceof LivingEntity attacker) {
                    // 伤害源设为玩家自己，避免循环触发（但若攻击者也持剑，仍可能触发其防反，概率低，可接受）
                    attacker.damage(player.getDamageSources().playerAttack(player), 15.0f);
                }
                // 取消伤害（返回 false）
                return false;
            }

            return true; // 未触发，允许伤害
        });
    }
}