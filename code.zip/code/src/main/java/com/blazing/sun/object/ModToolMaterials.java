package com.blazing.sun.object;   // 必须与主类相同

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.util.Lazy;

import java.util.function.Supplier;

public enum ModToolMaterials implements ToolMaterial {
    BLAZING_SWORD(114514, 12.0F, 0.0F, 67, () -> Ingredient.EMPTY);

    private final int durability;
    private final float attackDamage;
    private final float miningSpeed;
    private final int enchantability;
    private final Lazy<Ingredient> repairIngredient;

    ModToolMaterials(int durability, float attackDamage, float miningSpeed,
                     int enchantability, Supplier<Ingredient> repairIngredient) {
        this.durability = durability;
        this.attackDamage = attackDamage;
        this.miningSpeed = miningSpeed;
        this.enchantability = enchantability;
        this.repairIngredient = new Lazy<>(repairIngredient);
    }

    @Override
    public int getDurability() { return this.durability; }

    @Override
    public float getMiningSpeedMultiplier() { return this.miningSpeed; }

    @Override
    public float getAttackDamage() { return this.attackDamage; }

    @Override
    public int getMiningLevel() { return 0; }

    @Override
    public int getEnchantability() { return this.enchantability; }

    @Override
    public Ingredient getRepairIngredient() { return this.repairIngredient.get(); }
}